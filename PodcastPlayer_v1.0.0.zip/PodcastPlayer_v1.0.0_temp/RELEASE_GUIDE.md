# 播客播放器项目 - Release 制作指南

本指南将帮助你为播客播放器项目制作release版本，包括依赖安装、程序打包和发布流程。

## 1. 环境准备

### 安装依赖

首先确保安装了项目所需的依赖：

```bash
pip install -r requirements.txt
```

主要依赖：
- Python 3.6+（推荐3.8或更高版本）
- requests 用于网络请求
- 标准库：tkinter（GUI）、sqlite3（数据存储）、xml.etree.ElementTree（XML解析）等

### 安装打包工具

如需将程序打包成可执行文件，安装PyInstaller：

```bash
pip install pyinstaller
```

## 2. 打包为可执行文件

### 使用PyInstaller打包

可以使用PyInstaller将Python脚本打包成独立的可执行文件，方便用户无需安装Python环境即可运行。

#### 为单个脚本打包

为`播客数据获得.py`打包：

```bash
pyinstaller --onefile --windowed --name="播客数据获得" --icon=your_icon.ico "播客数据获得.py"
```

为`播客标注管理.py`打包：

```bash
pyinstaller --onefile --windowed --name="播客标注管理" --icon=your_icon.ico "播客标注管理.py"
```

#### 参数说明：
- `--onefile`：将所有内容打包成单个可执行文件
- `--windowed`：不显示控制台窗口（适用于GUI程序）
- `--name`：指定输出的可执行文件名
- `--icon`：添加程序图标（可选）

### 打包后的文件结构

打包完成后，会在项目目录下生成以下文件夹：
- `build/`：构建过程中的临时文件
- `dist/`：包含最终的可执行文件

## 3. 创建完整的Release包

一个完整的release包应该包含以下内容：

1. 可执行文件（`播客数据获得.exe`和`播客标注管理.exe`）
2. 必要的目录结构（`albums/`文件夹）
3. 系统数据库文件（`podcast_system.db`）
4. 说明文档（README.md）
5. 示例数据（"刷音频demo-泛娱乐"文件夹）

### 手动创建Release包

1. 创建一个新的文件夹，命名为`PodcastPlayer_v1.x.x`（x.x代表版本号）
2. 将以下内容复制到这个文件夹中：
   - dist目录下的可执行文件
   - albums文件夹（确保为空或包含示例数据）
   - podcast_system.db文件
   - README.md文件
   - "刷音频demo-泛娱乐"文件夹
3. 压缩这个文件夹为ZIP文件，便于分发

## 4. 版本管理

在每次发布新版本时，应该：

1. 更新README.md中的版本信息
2. 在RELEASE_GUIDE.md中记录版本变更
3. 使用语义化版本号（例如v1.0.0, v1.1.0, v1.1.1等）

### 版本号说明
- 主版本号（第一个数字）：不兼容的API变更
- 次版本号（第二个数字）：向下兼容的功能性新增
- 修订号（第三个数字）：向下兼容的问题修正

## 5. 发布注意事项

1. **测试**：在发布前，确保在不同的Windows环境下测试程序
2. **兼容性**：注意Windows系统版本兼容性，特别是关于文件路径和权限的处理
3. **数据迁移**：如果有数据库结构变更，提供数据迁移指南
4. **安全**：确保不包含敏感信息，如API密钥等
5. **用户指南**：提供清晰的使用说明，帮助用户快速上手

## 6. 制作GitHub Release

如果使用GitHub托管代码，可以创建正式的Release：

1. 登录GitHub，进入项目仓库
2. 点击"Releases"或"Draft a new release"
3. 填写版本号、标题和发布说明
4. 上传打包好的ZIP文件
5. 点击"Publish release"完成发布

## 7. 常见问题解决

### 打包失败
- 确保所有依赖都已正确安装
- 检查PyInstaller版本是否兼容
- 对于复杂依赖，可能需要使用`--hidden-import`参数指定隐藏的导入

### 运行时错误
- 检查文件路径问题，确保程序可以正确访问所需文件
- 对于数据库相关错误，检查文件权限和锁定问题
- 查看日志文件获取详细错误信息

## 版本历史

### v1.0.0（初始版本）
- 包含播客数据获得和播客标注管理两个主要功能模块
- 支持批量获取播客专辑和单集数据
- 支持音频播放同时编辑标注
- 提供刷音频demo示例